# python-practical-notes
This repo contains of all the python basic to advanced concepts with practical implementation done from my understanding.
hope it helps you at some point of time :)
